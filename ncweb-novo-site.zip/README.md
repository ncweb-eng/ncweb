# NCWEB — novo site

Projeto em Next.js com App Router, TypeScript e CSS próprio.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Produção

```bash
npm run build
npm start
```

## Estrutura

- `/` Home
- `/planos` Planos
- `/empresarial` Soluções empresariais
- `/cobertura` Consulta de cobertura
- `/suporte` Suporte
- `/contato` Contato

## Próximas integrações

1. Integrar formulário de cobertura ao SGP.
2. Substituir URLs de Central/WhatsApp pelos endereços definitivos.
3. Integrar status da rede ao Zabbix/API.
4. Inserir logo oficial da NCWEB em `/public`.
5. Configurar analytics, SEO local e conversões.
