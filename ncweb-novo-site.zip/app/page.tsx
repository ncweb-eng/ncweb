import Link from "next/link";
import {
  ArrowRight, Check, ChevronRight, Gauge, Headphones, MapPin,
  Network, RadioTower, Router, ShieldCheck, Sparkles, Wifi, Zap
} from "lucide-react";

const plans = [
  { speed: "300", title: "Essencial", description: "Para navegar, estudar e assistir.", tag: "Entrada" },
  { speed: "500", title: "Turbo", description: "Mais velocidade para toda a família.", tag: "Popular" },
  { speed: "700", title: "Ultra", description: "Alta performance para uma casa conectada.", tag: "Mais vendido" },
  { speed: "1", title: "Gigabit", description: "Máxima velocidade para quem exige mais.", tag: "Premium" },
];

const services = [
  { icon: Wifi, title: "Internet Residencial", text: "Fibra óptica para streaming, jogos, trabalho e estudo." },
  { icon: Network, title: "Internet Empresarial", text: "Conectividade estável para empresas que não podem parar." },
  { icon: Gauge, title: "Link Dedicado", text: "Performance e disponibilidade para operações críticas." },
  { icon: Router, title: "Interligação", text: "Conecte unidades, escritórios, POPs e estruturas." },
  { icon: RadioTower, title: "Links de Rádio", text: "Soluções para locais onde a fibra ainda não chegou." },
  { icon: Network, title: "Projetos de Backbone", text: "Infraestrutura e conectividade para projetos de telecom." },
];

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-grid" />
        <div className="container hero-inner">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse" /> Rede NCWEB operacional</div>
            <h1>Internet que<br /><span>conecta</span> o seu futuro.</h1>
            <p>Fibra óptica, alta velocidade e tecnologia para sua casa, sua empresa e seus projetos.</p>
            <div className="hero-actions">
              <Link href="/planos" className="btn btn-primary">Ver planos <ArrowRight size={18} /></Link>
              <Link href="/cobertura" className="btn btn-ghost">Ver cobertura</Link>
            </div>
            <div className="hero-proof">
              <div><strong>100%</strong><span>fibra óptica</span></div>
              <div><strong>24/7</strong><span>conectividade</span></div>
              <div><strong>PA</strong><span>presença regional</span></div>
            </div>
          </div>

          <div className="network-orbit" aria-label="Representação visual da rede">
            <div className="orbit orbit-a" />
            <div className="orbit orbit-b" />
            <div className="orbit orbit-c" />
            <div className="core-node"><Zap size={34} /><small>NCWEB</small></div>
            <div className="sat sat-1"><Wifi size={20} /></div>
            <div className="sat sat-2"><Network size={20} /></div>
            <div className="sat sat-3"><RadioTower size={20} /></div>
            <div className="sat sat-4"><Router size={20} /></div>
          </div>
        </div>
      </section>

      <section className="status-strip">
        <div className="container status-grid">
          <div className="status-title"><span className="status-dot" /> Status da rede</div>
          <div><span className="mini-dot" /> Internet</div>
          <div><span className="mini-dot" /> Backbone</div>
          <div><span className="mini-dot" /> DNS</div>
          <Link href="/suporte">Central de suporte <ChevronRight size={16} /></Link>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <div><span className="kicker">Conectividade para todos</span><h2>Uma rede. <span>Várias possibilidades.</span></h2></div>
            <p>Do Wi-Fi da sua casa ao link crítico da sua empresa, a NCWEB entrega soluções pensadas para cada necessidade.</p>
          </div>
          <div className="service-grid">
            {services.map((s) => {
              const Icon = s.icon;
              return <div className="service-card" key={s.title}><div className="icon-box"><Icon size={23} /></div><h3>{s.title}</h3><p>{s.text}</p><Link href="/contato">Saiba mais <ArrowRight size={16} /></Link></div>
            })}
          </div>
        </div>
      </section>

      <section className="dark-section">
        <div className="container split">
          <div>
            <span className="kicker">Feita para sua rotina</span>
            <h2>Mais que internet.<br /><span>Uma experiência NCWEB.</span></h2>
            <p className="lead">Conectividade de verdade precisa ser rápida, estável e ter suporte quando você precisar.</p>
            <div className="check-list">
              {["Fibra óptica de alta velocidade", "Suporte humanizado", "Wi-Fi e equipamentos conforme o plano", "Central do assinante", "Soluções para residências e empresas"].map(x => <div key={x}><Check size={18} /> {x}</div>)}
            </div>
          </div>
          <div className="feature-panel">
            <div className="panel-glow" />
            <div className="panel-top"><span>NCWEB NETWORK</span><span className="live"><span className="mini-dot" /> LIVE</span></div>
            <div className="map-lines"><span /><span /><span /><span /><span /></div>
            <div className="panel-stats"><div><small>REDE</small><strong>ONLINE</strong></div><div><small>TECNOLOGIA</small><strong>FTTH</strong></div><div><small>SUPORTE</small><strong>24/7</strong></div></div>
          </div>
        </div>
      </section>

      <section className="section plans-section">
        <div className="container">
          <div className="section-head">
            <div><span className="kicker">Planos residenciais</span><h2>Escolha sua <span>velocidade.</span></h2></div>
            <Link href="/planos" className="text-link">Ver todos os planos <ArrowRight size={17} /></Link>
          </div>
          <div className="plans-grid">
            {plans.map((p, i) => <div className={`plan-card ${i === 2 ? "featured" : ""}`} key={p.speed}>
              <div className="plan-tag">{p.tag}</div>
              <h3>{p.title}</h3>
              <div className="speed"><strong>{p.speed}</strong><span>{p.speed === "1" ? "Giga" : "Mega"}</span></div>
              <p>{p.description}</p>
              <div className="plan-line" />
              <div className="plan-benefits"><span><Check size={15} /> Fibra óptica</span><span><Check size={15} /> Wi-Fi</span><span><Check size={15} /> Velocidade ilimitada</span></div>
              <Link href="/planos" className="btn btn-dark">Consultar plano <ArrowRight size={16} /></Link>
            </div>)}
          </div>
          <p className="small-note">Planos e disponibilidade podem variar por endereço. Consulte a cobertura e as condições comerciais vigentes.</p>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-box">
          <div><span className="kicker">Ainda não é cliente?</span><h2>Descubra o que a NCWEB pode fazer por você.</h2><p>Consulte a disponibilidade no seu endereço em poucos passos.</p></div>
          <Link href="/cobertura" className="btn btn-primary">Consultar cobertura <MapPin size={18} /></Link>
        </div>
      </section>

      <section className="section trust-section">
        <div className="container trust-grid">
          <div className="trust-item"><ShieldCheck size={25} /><div><strong>Conectividade confiável</strong><p>Infraestrutura pensada para estabilidade.</p></div></div>
          <div className="trust-item"><Headphones size={25} /><div><strong>Suporte humanizado</strong><p>Atendimento para resolver, não complicar.</p></div></div>
          <div className="trust-item"><Sparkles size={25} /><div><strong>Tecnologia</strong><p>Rede preparada para alta velocidade.</p></div></div>
        </div>
      </section>
    </main>
  );
}
