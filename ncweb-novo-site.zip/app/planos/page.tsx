import Link from "next/link";
import { Check, ArrowRight, MapPin } from "lucide-react";

const plans = [
  ["300", "Essencial", "Para navegar, estudar e assistir."],
  ["500", "Turbo", "Mais velocidade para toda a família."],
  ["700", "Ultra", "Alta performance para uma casa conectada."],
  ["1 Giga", "Gigabit", "Máxima velocidade para quem exige mais."]
];

export default function Planos() {
  return <main className="inner-page">
    <section className="page-hero"><div className="container"><span className="kicker">Internet residencial</span><h1>Planos para <span>cada momento.</span></h1><p>Escolha a velocidade ideal para sua casa e consulte a disponibilidade no seu endereço.</p></div></section>
    <section className="section"><div className="container"><div className="plans-grid large">
      {plans.map((p, i) => <article className={`plan-card ${i===2 ? "featured" : ""}`} key={p[0]}><div className="plan-tag">{i===2 ? "Mais vendido" : "Fibra óptica"}</div><h3>{p[1]}</h3><div className="speed"><strong>{p[0]}</strong><span>{p[0] === "1 Giga" ? "" : "Mega"}</span></div><p>{p[2]}</p><div className="plan-line"/><div className="plan-benefits"><span><Check size={15}/> Fibra óptica</span><span><Check size={15}/> Wi-Fi</span><span><Check size={15}/> Velocidade ilimitada</span><span><Check size={15}/> Suporte</span></div><Link href="/cobertura" className="btn btn-dark">Consultar disponibilidade <ArrowRight size={16}/></Link></article>)}
    </div></div></section>
    <section className="cta-section"><div className="container cta-box"><div><span className="kicker">Seu endereço é o próximo passo</span><h2>Veja se a fibra NCWEB já chegou até você.</h2></div><Link href="/cobertura" className="btn btn-primary">Ver cobertura <MapPin size={18}/></Link></div></section>
  </main>
}
