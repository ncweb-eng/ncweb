"use client";
import { useState } from "react";
import { MapPin, Search, CheckCircle2 } from "lucide-react";

export default function Cobertura() {
  const [sent, setSent] = useState(false);
  return <main className="inner-page">
    <section className="page-hero"><div className="container"><span className="kicker">Disponibilidade</span><h1>Onde a NCWEB <span>está.</span></h1><p>Consulte a disponibilidade informando seu endereço. Nossa equipe confirma a viabilidade.</p></div></section>
    <section className="section"><div className="container coverage-layout"><div className="coverage-card"><div className="coverage-title"><MapPin size={22}/><div><h2>Consultar cobertura</h2><p>Preencha os dados abaixo.</p></div></div>{sent ? <div className="success"><CheckCircle2 size={42}/><h3>Recebemos sua solicitação!</h3><p>Nossa equipe entrará em contato para confirmar a viabilidade.</p><button className="btn btn-dark" onClick={()=>setSent(false)}>Nova consulta</button></div> : <form onSubmit={e=>{e.preventDefault();setSent(true)}}><label>Nome<input required placeholder="Seu nome"/></label><label>WhatsApp<input required placeholder="(91) 99999-9999"/></label><label>Endereço<input required placeholder="Rua, número, bairro"/></label><label>Cidade<input required defaultValue="Belém - PA"/></label><button className="btn btn-primary" type="submit">Consultar cobertura <Search size={17}/></button></form>}</div><div className="coverage-map"><div className="map-grid"/><div className="map-pin p1"/><div className="map-pin p2"/><div className="map-pin p3"/><div className="map-label">REDE NCWEB<br/><small>PA</small></div></div></div></section>
  </main>
}
