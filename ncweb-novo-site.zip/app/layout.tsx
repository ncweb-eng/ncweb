import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  title: "NCWEB | Internet que conecta você ao futuro",
  description: "Internet fibra, soluções empresariais e conectividade para Belém e região.",
  metadataBase: new URL("https://www.ncweb.com.br"),
  openGraph: {
    title: "NCWEB | Internet que conecta você ao futuro",
    description: "Fibra óptica, internet empresarial e conectividade.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
