import Link from "next/link";
import { ArrowRight, Check, Network, ShieldCheck, Gauge, RadioTower } from "lucide-react";

const items = [
  ["Link Dedicado", "Conectividade empresarial com performance e previsibilidade.", Gauge],
  ["Interligação de Empresas", "Conecte filiais, escritórios e estruturas com segurança.", Network],
  ["Backbone e Transporte", "Projetos de conectividade para operações de telecom.", RadioTower],
  ["Internet Empresarial", "Banda larga para equipes, sistemas e operações.", ShieldCheck],
];

export default function Empresarial() {
  return <main className="inner-page">
    <section className="business-hero"><div className="container split"><div><span className="kicker">NCWEB Empresas</span><h1>Seu negócio não pode <span>parar.</span></h1><p>Conectividade para empresas que precisam de velocidade, estabilidade e suporte.</p><Link href="/contato" className="btn btn-primary">Falar com especialista <ArrowRight size={18}/></Link></div><div className="business-art"><div className="big-node">NC</div><div className="business-line l1"/><div className="business-line l2"/><div className="business-line l3"/></div></div></section>
    <section className="section"><div className="container"><div className="section-head"><div><span className="kicker">Soluções</span><h2>Conectividade <span>sob medida.</span></h2></div></div><div className="service-grid">{items.map(([title,text,Icon]) => <article className="service-card" key={title}><div className="icon-box"><Icon size={23}/></div><h3>{title}</h3><p>{text}</p><Link href="/contato">Solicitar proposta <ArrowRight size={16}/></Link></article>)}</div></div></section>
    <section className="dark-section"><div className="container split"><div><span className="kicker">Projetos</span><h2>Da última milha ao <span>backbone.</span></h2><p className="lead">Nossa estrutura permite criar soluções para diferentes níveis de criticidade e escala.</p></div><div className="check-list">{["Projetos personalizados", "Monitoramento e suporte", "Interligação de unidades", "Transporte de dados", "Escalabilidade"].map(x=><div key={x}><Check size={18}/> {x}</div>)}</div></div></section>
  </main>
}
