import Link from "next/link";
import { Headphones, MessageCircle, FileText, Wifi, ArrowRight } from "lucide-react";

const cards = [
  [MessageCircle, "WhatsApp", "Fale com nossa equipe de atendimento.", "https://wa.me/559140424402", "Abrir WhatsApp"],
  [FileText, "Central do assinante", "Acesse boletos, chamados e serviços.", "https://central.ncweb.com.br/", "Acessar central"],
  [Wifi, "Problemas de conexão", "Confira orientações básicas antes de abrir um chamado.", "/contato", "Preciso de ajuda"],
  [Headphones, "Atendimento", "Nossa equipe está pronta para ajudar.", "/contato", "Falar com suporte"]
];

export default function Suporte() {
  return <main className="inner-page"><section className="page-hero"><div className="container"><span className="kicker">Estamos aqui</span><h1>Como podemos <span>ajudar?</span></h1><p>Encontre o canal certo para resolver sua necessidade.</p></div></section><section className="section"><div className="container service-grid">{cards.map(([Icon,title,text,href,cta])=><article className="service-card support-card" key={title}><div className="icon-box"><Icon size={23}/></div><h3>{title as string}</h3><p>{text as string}</p><Link href={href as string}>{cta as string} <ArrowRight size={16}/></Link></article>)}</div></section></main>
}
