import Link from "next/link";
import { Instagram, Facebook, MessageCircle, MapPin, Phone, Mail } from "lucide-react";

export function Footer() {
  return <footer className="footer">
    <div className="container footer-grid">
      <div className="footer-brand"><Link href="/" className="logo"><span>NC</span>WEB</Link><p>Conectando você ao que importa.</p><div className="socials"><a href="#" aria-label="Instagram"><Instagram size={18}/></a><a href="#" aria-label="Facebook"><Facebook size={18}/></a><a href="https://wa.me/559140424402" aria-label="WhatsApp"><MessageCircle size={18}/></a></div></div>
      <div><h4>Empresa</h4><Link href="/empresarial">Soluções empresariais</Link><Link href="/cobertura">Cobertura</Link><Link href="/suporte">Suporte</Link><Link href="/contato">Contato</Link></div>
      <div><h4>Atendimento</h4><a href="https://central.ncweb.com.br/">Central do assinante</a><a href="https://wa.me/559140424402">WhatsApp</a><a href="tel:+559140424402">Telefone</a><a href="mailto:contato@ncweb.com.br">E-mail</a></div>
      <div><h4>Belém</h4><p className="address"><MapPin size={16}/> Av. Pedro Miranda, 1755, sala 04 — Pedreira</p><p className="address"><Phone size={16}/> (91) 4042-4402</p><p className="address"><Mail size={16}/> contato@ncweb.com.br</p></div>
    </div>
    <div className="container footer-bottom"><span>© {new Date().getFullYear()} NCWEB. Todos os direitos reservados.</span><span>Internet • Fibra • Tecnologia</span></div>
  </footer>;
}
