"use client";
import Link from "next/link";
import { Menu, X, ChevronDown, UserRound } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="header">
      <div className="container nav">
        <Link href="/" className="logo" onClick={() => setOpen(false)}><span>NC</span>WEB</Link>
        <nav className={open ? "nav-links open" : "nav-links"}>
          <Link href="/planos" onClick={() => setOpen(false)}>Planos</Link>
          <Link href="/empresarial" onClick={() => setOpen(false)}>Empresas</Link>
          <Link href="/cobertura" onClick={() => setOpen(false)}>Cobertura</Link>
          <Link href="/suporte" onClick={() => setOpen(false)}>Suporte</Link>
          <Link href="/contato" onClick={() => setOpen(false)}>Contato</Link>
        </nav>
        <div className="nav-actions">
          <a href="https://central.ncweb.com.br/" className="client-btn" target="_blank" rel="noreferrer"><UserRound size={17} /> Área do cliente</a>
          <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
        </div>
      </div>
    </header>
  );
}
